<?php require_once "vistas/parte_superior.php"?>

<!--INICIO del cont principal-->
<div class="container">
    <h1>Página de buttons</h1>
</div>
<!--FIN del cont principal-->

<?php require_once "vistas/parte_inferior.php"?>