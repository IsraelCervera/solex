<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\PaymentPlatform;
use Faker\Generator as Faker;

$factory->define(PaymentPlatform::class, function (Faker $faker) {
    return [
        //
    ];
});
