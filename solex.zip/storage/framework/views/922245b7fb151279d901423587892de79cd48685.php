<?php $__env->startSection('title','Registrar empresa'); ?>
<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('options'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('preference'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="page-header">
        <h3 class="page-title">
            Registro de empresa
        </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Panel administrador</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('businesses.index')); ?>">Empresa</a></li>
                <li class="breadcrumb-item active" aria-current="page">Registro de empresa</li>
            </ol>
        </nav>
    </div>
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    
                    <div class="d-flex justify-content-between">
                        <h4 class="card-title">Registro de empresa</h4>
                    </div>
                    <form method="POST" files=true action="<?php echo e(route('businesses.store')); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                        <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        </div>
                        <?php endif; ?>
                   

                    <div class="form-group">
                      <label for="name">Nombre</label>
                      <input type="text" name="name" id="name" class="form-control" aria-describedby="helpId" required>
                    </div>
                    <div class="form-group">
                      <label for="description">Acerca de</label>
                      <textarea class="form-control" name="description" id="description" rows="3"></textarea>
                    </div>
                    <div class="form-group">
                      <label for="description_long">Descripción</label>
                      <textarea class="form-control" name="description_long" id="description_long" rows="3"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="phone">Celular</label>
                        <input type="number" name="phone" id="phone" class="form-control" aria-describedby="helpId" required>
                    </div>
                    <div class="form-group">
                      <label for="mail">Correo</label>
                      <input type="email" name="mail" id="mail" class="form-control" aria-describedby="helpId" required>
                    </div>
                    <div class="form-group">
                      <label for="address">Dirección</label>
                      <textarea class="form-control" name="address" id="address" rows="3"></textarea>
                    </div>
                    <div class="form-group">
                      <label for="hours_of_operation">Horario</label>
                      <input type="text" name="hours_of_operation" id="hours_of_operation" class="form-control" aria-describedby="helpId" required>
                    </div>
                    <div class="form-group">
                      <label for="contact_text">Texto de contacto</label>
                      <textarea class="form-control" name="contact_text" id="contact_text" rows="3"></textarea>
                    </div>
                    <div class="form-group">
                      <label for="google_maps_link">Link de Google Maps</label>
                      <input type="text" name="google_maps_link" id="google_maps_link" class="form-control" aria-describedby="helpId" required>
                    </div>


                    <div class="card-body">
                        <h4 class="card-title d-flex">Logo de la empresa
                          <small class="ml-auto align-self-end">
                            <a href="dropify.html" class="font-weight-light" target="_blank">Seleccionar Archivo</a>
                          </small>
                        </h4>
                        <input type="file"  name="picture" id="picture" class="dropify" />
                    </div>

                     <button type="submit" class="btn btn-primary mr-2">Registrar</button>
                     <a href="<?php echo e(route('businesses.index')); ?>" class="btn btn-light">
                        Cancelar
                     </a>
                     </form>
                </div>
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('melody/js/data-table.js')); ?>"></script>
<script src="<?php echo e(asset('melody/js/dropify.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\solex\resources\views/admin/business/create.blade.php ENDPATH**/ ?>