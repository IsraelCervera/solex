<?php $__env->startSection('contenido'); ?>

<html>
<head>

<link rel="shortcut icon" href="<?php echo e(asset('estilos/dashboard/img/user.png')); ?>">
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Login</title>

        <link rel="stylesheet" href="<?php echo e(asset('estilos/bootstrap/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('estilos/estilos.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('estilos/plugins/sweetalert2/sweetalert2.min.css')); ?>">     
        
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('estilos/fuentes/iconic/css/material-design-iconic-font.min.css')); ?>">
		</head>

		<body>

            <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    <?php if(session('message')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('message')); ?>

    </div>
<?php endif; ?>

		<div class="container-login">
        <div class="wrap-login">
            <form class="login-form validate-form" action="login" method="POST">
                <span class="login-form-title">LOGIN</span>
     	<?php echo csrf_field(); ?>

	<div class="wrap-input100" data-validate = "Usuario incorrecto">
                    <input class="input100" type="text" id="email" name="email" placeholder="Email">
                    <span class="focus-efecto"></span>
                </div>
                
                <div class="wrap-input100" data-validate="Password incorrecto">
                    <input class="input100" type="password" id="password" name="password" placeholder="Password">
                    <span class="focus-efecto"></span>
                </div>
                
                <div class="container-login-form-btn">
                    <div class="wrap-login-form-btn">
                        <div class="login-form-bgbtn"></div>
                        <button type="submit" name="submit" class="login-form-btn">INICIAR SESIÓN</button>
                    </div>
                </div>
            </form>
            <div class="container-login-form-btn">
                    <div class="wrap-login-form-btn">
                        <div class="login-form-bgbtn"></div>
                        <button class="login-form-btn" onclick="location.href='<?php echo e(route('users.create')); ?>'">REGISTRARSE</button>
                    </div>
                </div>
        </div>
    </div>     

    </body>
     <br>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GamingShop\resources\views/login.blade.php ENDPATH**/ ?>