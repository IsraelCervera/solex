<?php $__env->startSection('title','Gestión de productos'); ?>
<?php $__env->startSection('styles'); ?>
<style type="text/css">
    .unstyled-button {
        border: none;
        padding: 0;
        background: none;
      }
</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('options'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('preference'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="page-header">
        <h3 class="page-title">
            Productos
        </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Panel administrador</a></li>
                <li class="breadcrumb-item active" aria-current="page">Productos</li>
            </ol>
        </nav>
    </div>
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    
                    <div class="d-flex justify-content-between">
                        <h4 class="card-title">Productos</h4>
                        
                        <div class="btn-group">
                            <a data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right">
                              <a href="<?php echo e(route('products.create')); ?>" class="dropdown-item">Agregar Producto</a>
                              <a class="dropdown-item" href="<?php echo e(route('print_barcode')); ?>">Exportar códigos de barras</a> 
                            </div>
                          </div>
                    </div>

                    <div class="table-responsive">
                        <table id="order-listing" class="table">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Nombre</th>
                                    <th>Stock</th>
                                    <th>Estado</th>
                                    <th>Categoría</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($product->id); ?></th>
                                    <td>
                                        <a href="<?php echo e(route('products.show',$product)); ?>"><?php echo e($product->name); ?></a>
                                    </td>
                                    <td><?php echo e($product->stock); ?></td>
                                    <?php if($product->status == 'ACTIVE'): ?>
                                    <td>
                                        <a class="jsgrid-button btn btn-success" href="<?php echo e(route('change.status.products', $product)); ?>" title="Editar">
                                            Activo <i class="fas fa-check"></i>
                                        </a>
                                    </td>
                                    <?php else: ?>
                                    <td>
                                        <a class="jsgrid-button btn btn-danger" href="<?php echo e(route('change.status.products', $product)); ?>" title="Editar">
                                            Desactivado <i class="fas fa-times"></i>
                                        </a>
                                    </td>
                                    <?php endif; ?>
                                    

                                    <td><?php echo e($product->category->name); ?></td>
                                    <td style="width: 50px;">

                                        <a class="jsgrid-button jsgrid-edit-button" href="<?php echo e(route('products.edit', $product)); ?>" title="Editar">
                                            <i class="far fa-edit"></i>
                                        </a>

                                        <form style="display:inline" method="POST" action="<?php echo e(route('products.destroy', $product)); ?>">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo method_field('DELETE'); ?>

                                        <button class="jsgrid-button jsgrid-delete-button unstyled-button" type="submit" title="Eliminar">
                                            <i class="far fa-trash-alt"></i>
                                        </button>
                                        </form>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('melody/js/data-table.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GamingShop\resources\views/admin/product/index.blade.php ENDPATH**/ ?>