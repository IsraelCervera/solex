<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

        <link rel="stylesheet" href="<?php echo e(asset('estilos/bootstrap/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo e(asset('estilos/background.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('estilos/estilos.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('estilos/plugins/sweetalert2/sweetalert2.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('estilos/fuentes/iconic/css/material-design-iconic-font.min.css')); ?>">        
  <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
	<title>Mi sitio</title>
</head>
<body>
       <header>  

              <?php
                   function activeMenu($url){
                   return request()->is($url) ? 'active' : '';
            }
            ?>
       	<nav class="navbar navbar-expand-lg navbar-light bg-light">
          <div class="container-fluid">
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">

       	   <li class="<?php echo e(activeMenu('inicio')); ?>">
           <a class="nav-link" href="<?php echo e(route('home')); ?>">Inicio</a>
           </li>

           <li class="<?php echo e(activeMenu('categories*')); ?>">
            <a class="nav-link" href="<?php echo e(route('categories.index')); ?>">Categorias</a>
           </li>


          </ul>

          <ul class="nav navbar-nav navbar-right">
            <?php if(auth()->check()): ?>
            <li class="<?php echo e(activeMenu('orders*')); ?>">
            <a class="nav-link" href="<?php echo e(route('web.orders')); ?>">Mis Pedidos</a>
           </li>
           <?php endif; ?>

            <li>
              <a class="text-dark" href="<?php echo e(route('cart.checkout')); ?>">CART<i class="fa fa-shopping-cart"></i><span class="badge badge-danger">
                <?php echo e($shopping_cart->quantity_of_products()); ?>

              </span></a>
            </li>

          <?php if(auth()->check()): ?>
          <?php if(auth()->user()->rol=='Administrador'): ?>

           <li class="<?php echo e(activeMenu('products*')); ?>">
            <a class="nav-link" href="<?php echo e(route('products.index')); ?>">Panel Administrador</a>
           </li>

           <?php endif; ?>
           <?php endif; ?>

           <?php if(auth()->guest()): ?>
           <li class="<?php echo e(activeMenu('login')); ?>">
          <a class="nav-link" href="login">Login</a>
           </li>
           <?php else: ?>
           <li class="dropdown">
            <a class="dropdown-toggle text-dark" data-toggle="dropdown" ><?php echo e(auth()->user()->name); ?><b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a class="nav-link" href="../public/logout">Cerrar sesión</a>
            </ul>
           </li>
           <?php endif; ?>
         </ul>
       </div>
     </div>
    </nav>
  </header>

      <div class="container-fluid">
       <?php echo $__env->yieldContent('contenido'); ?>
     </div>
     <div>
       <footer class="text-dark align-middle">Copyright GamingShop <?php echo e(date('Y')); ?></footer>
     </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\Gaming\resources\views/layout.blade.php ENDPATH**/ ?>