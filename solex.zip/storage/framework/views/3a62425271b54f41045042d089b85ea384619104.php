<?php $__env->startSection('contenido'); ?>
<h1>Comentario</h1>
<p>Comentario de <?php echo e($comments->user->name); ?> <?php echo e($comments->user->lastname); ?></p>
<p><?php echo e($comments->body); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GamingShop\resources\views/comments/show.blade.php ENDPATH**/ ?>