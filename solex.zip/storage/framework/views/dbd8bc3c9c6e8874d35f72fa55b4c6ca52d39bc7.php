<?php $__env->startSection('contenido'); ?>

        <link rel="stylesheet" href="<?php echo e(asset('estilos/bootstrap/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('estilos/estilos.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('estilos/plugins/sweetalert2/sweetalert2.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('estilos/fuentes/iconic/css/material-design-iconic-font.min.css')); ?>"> 

<h1>Usuario</h1>
<p>Registro de <?php echo e($users->name); ?> - <?php echo e($users->email); ?></p>
<p><?php echo e($users->rol); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GamingShop\resources\views/users/show.blade.php ENDPATH**/ ?>