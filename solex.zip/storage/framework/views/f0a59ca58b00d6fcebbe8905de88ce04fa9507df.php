<?php $__env->startSection('contenido'); ?>
<h1>Comentarios</h1>
<table class="table">
	<thead>
		<tr>
			<th>ID</th>
			<th>Comentario</th>
			<th>Acciones</th>
		</tr>
	</thead>
	<tbody>
		<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><a href="<?php echo e(route('comentarios.show', $comment->id)); ?>">
			<?php echo e($comment->id); ?> </a></td>
			<td><?php echo e($comment->body); ?></td>
			<td><button class="btn btn-info" onclick="location.href='<?php echo e(route('comentarios.edit', $comment->id)); ?>'">
			Editar</button>

			<form style="display:inline" method="POST" action="<?php echo e(route('comentarios.destroy', $comment->id)); ?>">

                <?php echo e(csrf_field()); ?>

                <?php echo method_field('DELETE'); ?>

					<button class="btn btn-danger" type="submit">Eliminar</button>
				</form>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Gaming\resources\views/comments/index.blade.php ENDPATH**/ ?>