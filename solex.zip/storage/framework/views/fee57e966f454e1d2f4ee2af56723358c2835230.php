<?php $__env->startSection('contenido'); ?>
<h1>Usuarios</h1>

        <link rel="stylesheet" href="<?php echo e(asset('estilos/bootstrap/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('estilos/estilos.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('estilos/plugins/sweetalert2/sweetalert2.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('estilos/fuentes/iconic/css/material-design-iconic-font.min.css')); ?>"> 

<button class="btn btn-info" onclick="location.href='<?php echo e(route('users.create')); ?>'">Agregar</button>
<table class="table">
	<thead>
		<tr>
			<th>ID</th>
			<th>Nombre</th>
			<th>Apellido</th>
			<th>Email</th>
			<th>Phone</th>
			<th>Rol</th>
			<td>Contraseña</td>
			<th>Acciones</th>
		</tr>
	</thead>
	<tbody>
		<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><a href="<?php echo e(route('users.show', $user->id)); ?>">
			<?php echo e($user->id); ?> </a></td>
			<td><?php echo e($user->name); ?></td>
			<td><?php echo e($user->lastname); ?></td>
			<td><?php echo e($user->email); ?></td>
			<td><?php echo e($user->phone); ?></td>
			<td><?php echo e($user->rol); ?></td>
			<td><?php echo e($user->password); ?></td>
			<td><button class="btn btn-info" onclick="location.href='<?php echo e(route('users.edit', $user->id)); ?>'">
			Editar</button>

			<form style="display:inline" method="POST" action="<?php echo e(route('users.destroy', $user->id)); ?>">

                <?php echo e(csrf_field()); ?>

                <?php echo method_field('DELETE'); ?>

					<button class="btn btn-danger" type="submit">Eliminar</button>
				</form>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GamingShop\resources\views/users/index.blade.php ENDPATH**/ ?>