<?php $__env->startSection('title','Detalles de pedido'); ?>
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('create'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('options'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('preference'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="page-header">
        <h3 class="page-title">
            Detalles de pedido
        </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <?php if(auth()->check()): ?>
                <?php if(auth()->user()->rol=='Administrador'): ?>
                <li class="breadcrumb-item"><a href="#">Panel administrador</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('orders.index')); ?>">Pedidos</a></li>
                <?php endif; ?>
                <?php endif; ?>
                <li class="breadcrumb-item active" aria-current="page">Detalles de Pedido</li>
            </ol>
        </nav>
    </div>

        <div class="row">
          <div class="col-12">

            <!-- Main content -->
            <div class="invoice p-3 mb-3">
              <!-- title row -->
              <div class="row">
                <div class="col-12">
                  <h4>
                    <i class="fas fa-globe"></i> <?php echo e($providers->name); ?>, Inc.
                    <small class="float-right"><?php echo e($order->order_date); ?></small>
                  </h4>
                </div>
                <!-- /.col -->
              </div>
              <!-- info row -->
              <div class="row invoice-info">
                <div class="col-sm-4 invoice-col">
                  De
                  <address>
                    <strong><?php echo e($providers->name); ?>, Inc.</strong>
                    <br><?php echo e($providers->address); ?><br>
                    Quintana Roo, CP 77800<br>
                    Phone: <?php echo e($providers->phone); ?><br>
                    Email: <?php echo e($providers->email); ?>

                  </address>
                </div>
                <!-- /.col -->
                <div class="col-sm-4 invoice-col">
                  Para
                  <address>
                    <strong><?php echo e($user->name); ?> <?php echo e($user->lastname); ?></strong>
                    <br><?php echo e($user->address); ?><br>
                    <?php echo e($user->state); ?>, <?php echo e($user->cp); ?><br>
                    Phone: <?php echo e($user->phone); ?><br>
                    Email: <?php echo e($user->email); ?>

                  </address>
                </div>
                <!-- /.col -->
                <div class="col-sm-4 invoice-col">
                  <b>Pedido ID:</b> <?php echo e($order->id); ?><br>
                  <b>Estado de pago:</b> <?php echo e($order->payment_status()); ?><br>
                  <b>Estado de envio:</b> <?php echo e($order->shipping_status()); ?><br>
                  <b>Fecha de pedido:</b> <?php echo e($order->order_date); ?>

                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <!-- Table row -->
              <div class="row">
                <div class="col-12 table-responsive">
                  <table class="table table-striped">
                    <thead>
                    <tr>
                      <th>Producto</th>
                      <th>Cantidad</th>
                      <th>Precio</th>
                      <th>Total($MX)</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($detail->product->name); ?></td>
                      <td><?php echo e($detail->quantity); ?></td>
                      <td><?php echo e($detail->price); ?></td>
                      <td>$MX <?php echo e($detail->total()); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <div class="row">
                <!-- accepted payments column -->
                <div class="col-6">
                  <p class="lead">Metodo de pago:</p>
                  <img src="<?php echo e(asset('img/payment-platforms/paypal.jpg')); ?>" alt="PayPal">
                  
                  <p class="text-muted well well-sm shadow-none" style="margin-top: 10px;">
                    Paga con PayPal la manera más segura.
                  </p>
                </div>
                <!-- /.col -->
                <div class="col-6">
                  <p class="lead">Amount Due 2/22/2014</p>

                  <div class="table-responsive">
                    <table class="table">
                      <tr>
                        <th style="width:50%">Subtotal:</th>
                        <td>$MX <?php echo e($order->subtotal()); ?></td>
                      </tr>
                      <tr>
                        <th>Impuestos (18%)</th>
                        <td>$MX <?php echo e($order->total_impuesto()); ?></td>
                      </tr>
                      <tr>
                        <th>Envio:</th>
                        <td>$0.00</td>
                      </tr>
                      <tr>
                        <th>Total:</th>
                        <td>$MX <?php echo e($order->total()); ?></td>
                      </tr>
                    </table>
                  </div>
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <!-- this row will not appear when printing -->
              <div class="row no-print">
                <div class="col-12">
                  <a href="invoice-print.html" rel="noopener" target="_blank" class="btn btn-default"><i class="fas fa-print"></i> Print</a>
                  <button type="button" class="btn btn-success float-right" onclick="location.href='<?php echo e(route('orders.ticket', $order)); ?>'"><i class="far fa-credit-card"></i> Generar Ticket
                  </button>
                  <button type="button" class="btn btn-primary float-right" onclick="location.href='<?php echo e(route('orders.pdf', $order)); ?>'" style="margin-right: 5px;">
                    <i class="fas fa-download"></i> Generar PDF
                  </button>
                </div>
              </div>
            </div>
            <!-- /.invoice -->
          </div><!-- /.col -->
        </div><!-- /.row -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('melody/js/profile-demo.js')); ?>"></script>
<script src="<?php echo e(asset('melody/js/data-table.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Gaming\resources\views/admin/order/show.blade.php ENDPATH**/ ?>