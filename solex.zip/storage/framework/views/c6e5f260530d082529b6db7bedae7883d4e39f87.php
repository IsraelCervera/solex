<?php $__env->startSection('title','Editar publicación'); ?>
<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('options'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('preference'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="page-header">
        <h3 class="page-title">
            Edición de publicaciones
        </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Panel administrador</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('posts.index')); ?>">Publicación</a></li>
                <li class="breadcrumb-item active" aria-current="page">Edición de publicación</li>
            </ol>
        </nav>
    </div>
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    
                    <div class="d-flex justify-content-between">
                        <h4 class="card-title">Edición de publicación</h4>
                    </div>

                    <form method="POST" action="<?php echo e(route('posts.update', $post)); ?>" enctype="multipart/form-data">
                        <?php echo method_field('PUT'); ?>

                        <?php echo e(csrf_field()); ?>

                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                        <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        </div>
                        <?php endif; ?>


                    <div class="form-group">
                      <label for="title">Titulo</label>
                      <input type="text" name="title" id="title" value="<?php echo e($post->title); ?>" class="form-control" aria-describedby="helpId" required>
                    </div>

                    <div class="form-group">
                        <label for="excerpt">Resumen de la publicación</label>
                        <textarea class="form-control" name="excerpt" id="excerpt" rows="3"><?php echo e($post->excerpt); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="body">Contenido de la publicación</label>
                        <textarea class="form-control" name="body" id="body" rows="3"><?php echo e($post->body); ?></textarea>
                    </div>
                   
                    <div class="card-body">
                        <h4 class="card-title d-flex">Imagen de publicación
                          <small class="ml-auto align-self-end">
                            <a href="dropify.html" class="font-weight-light" target="_blank">Seleccionar Archivo</a>
                          </small>
                        </h4>
                        <input type="file"  name="picture" id="picture" class="dropify" />
                    </div>

                     <button type="submit" class="btn btn-primary mr-2">Actualizar</button>
                     <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-light">
                        Cancelar
                     </a>
                     </form>
                </div>
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('melody/js/dropify.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\solex\resources\views/admin/post/edit.blade.php ENDPATH**/ ?>