
<div class="blog-thumb img-full fix">
    <a href="blog-details.html">
        <img src="<?php echo e(asset('slug/'.$post->slug)); ?>" alt="">
    </a>
</div>
<?php /**PATH C:\xampp\htdocs\solex\resources\views/web/blog/_blog_thumb.blade.php ENDPATH**/ ?>