<?php $__env->startSection('title','Productos de categoría'); ?>
<?php $__env->startSection('styles'); ?>
<style type="text/css">
    .unstyled-button {
        border: none;
        padding: 0;
        background: none;
      }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('create'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('options'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('preference'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="page-header">
        <h3 class="page-title">
            Productos que pertenecen a <?php echo e($category->name); ?>

        </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <?php if(auth()->check()): ?>
                <?php if(auth()->user()->rol=='Administrador'): ?>
                <li class="breadcrumb-item"><a href="<?php echo e(route('categories.index')); ?>">Panel administrador</a></li>
                <?php endif; ?>
                <?php endif; ?>
                <li class="breadcrumb-item"><a href="<?php echo e(route('categories.index')); ?>">Categorías</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($category->name); ?></li>
            </ol>
        </nav>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    

                    <div class="d-flex justify-content-between">
                        <h4 class="card-title">Productos de la categoría <?php echo e($category->name); ?></h4>
                        
                        <div class="btn-group">
                            <a data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right">
                               
                            </div>
                          </div>
                    </div>

                    <div class="table-responsive">
                        <table id="order-listing" class="table">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Nombre</th>
                                    <th>Categoría</th>
                                    <th>Stock</th>
                                    <?php if(auth()->check()): ?>
                                    <?php if(auth()->user()->rol=='Administrador'): ?>
                                    <th>Estado</th>
                                    <th>Acciones</th>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($product->id); ?></th>
                                    <td>
                                        <a href="<?php echo e(route('products.show',$product)); ?>"><?php echo e($product->name); ?></a>
                                    </td>
                                    <td><?php echo e($product->category->name); ?></td>
                                    <td><?php echo e($product->stock); ?></td>

                                    <?php if(auth()->check()): ?>
                                    <?php if(auth()->user()->rol=='Administrador'): ?>

                                    <?php if($product->status == 'ACTIVE'): ?>
                                    <td>
                                        <a class="jsgrid-button btn btn-success" href="<?php echo e(route('change.status.products', $product)); ?>" title="Editar">
                                            Activo <i class="fas fa-check"></i>
                                        </a>
                                    </td>
                                    <?php else: ?>
                                    <td>
                                        <a class="jsgrid-button btn btn-danger" href="<?php echo e(route('change.status.products', $product)); ?>" title="Editar">
                                            Desactivado <i class="fas fa-times"></i>
                                        </a>
                                    </td>
                                    <?php endif; ?>
                                    

                                    <td style="width: 50px;">

                                        <a class="jsgrid-button jsgrid-edit-button" href="<?php echo e(route('products.edit', $product)); ?>" title="Editar">
                                            <i class="far fa-edit"></i>
                                        </a>

                                        <form style="display:inline" method="POST" action="<?php echo e(route('products.destroy', $product)); ?>">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo method_field('DELETE'); ?>

                                        
                                        <button class="jsgrid-button jsgrid-delete-button unstyled-button" type="submit" title="Eliminar">
                                            <i class="far fa-trash-alt"></i>
                                        </button>

                                        </form>
                                    </td>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>


                </div>
                <div class="card-footer text-muted">
                    <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-primary float-right">Regresar</a>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('melody/js/profile-demo.js')); ?>"></script>
<script src="<?php echo e(asset('melody/js/data-table.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Gaming\resources\views/admin/category/show.blade.php ENDPATH**/ ?>