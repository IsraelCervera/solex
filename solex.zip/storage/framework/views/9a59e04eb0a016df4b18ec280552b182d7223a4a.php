<hr>
<h4>Comentarios</h4>
<hr>

<link rel="stylesheet" href="<?php echo e(asset('estilos/style.css')); ?>">

<?php if(session('message')): ?>
    <div class="alert alert-success">
    	<?php echo e(session('message')); ?>

	</div>
<?php endif; ?>

<?php if(Auth::check()): ?>
<form class="col-md-4" method="POST" action="<?php echo e(route('comentarios.store')); ?>">
	<?php echo e(csrf_field()); ?>

	<?php if($errors->any()): ?>
    <div class="alert alert-danger">
     	<ul>
	        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	        <li><?php echo e($error); ?></li>
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    </ul>
	</div>
<?php endif; ?>
	<input type="hidden" name="product_id" value="<?php echo e($product->id); ?>" required>
	<p>
		<textarea class="form-control" name="body"><?php echo e(old('body')); ?></textarea>
		<input type="submit" name="Comentar" value="Comentar" class="btn btn-primary">
	</p>
</form>
<?php endif; ?>
<?php if(isset($product->comments)): ?>
<br>
   <div id="comments-list">
   	<?php $__currentLoopData = $product->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   	<div class="comment-item col-md-6 pull-left">
   		<div class="panel panel-default comment-data">
			<div class="panel-heading">
				<div class="panel-title">
					<?php echo e($comment->user->name.' '.$comment->user->lastname.' '.\FormatTime::LongTimeFilter($comment->created_at)); ?>

				</div>
				
			</div>
			<div class="panel-body">
				<?php echo e($comment->body); ?>

				<br>

				<?php if(Auth::check() && Auth::user()->id == $comment->user_id): ?>
				<a href="<?php echo e(route('comentarios.edit', $comment->id)); ?>" role="button" class="btn btn-sm btn-warning">Editar</a>

				<?php if(Auth::check() && (Auth::user()->id == $comment->user_id || Auth::user()->id == $product->provider_id)): ?>

		<!-- Botón en HTML (lanza el modal en Bootstrap) -->
<a href="#victorModal<?php echo e($comment->id); ?>" role="button" class="btn btn-sm btn-warning" data-toggle="modal">Eliminar</a>
  
<!-- Modal / Ventana / Overlay en HTML -->
<div id="victorModal<?php echo e($comment->id); ?>" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">¿Estás seguro?</h4>
            </div>
            <div class="modal-body">
                <p>¿Seguro que quieres borrar el comentario?</p>
                <p class="text-warning"><small><?php echo e($comment->body); ?></small></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                <form style="display:inline" method="POST" action="<?php echo e(route('comentarios.destroy', $comment->id)); ?>">

                <?php echo e(csrf_field()); ?>

                <?php echo method_field('DELETE'); ?>

					<button class="btn btn-default" type="submit">Eliminar</button>
				</form>
            </div>
        </div>
    </div>
</div>
		<?php endif; ?>
		<?php endif; ?>

		<hr><hr>
			</div>
		</div>
	</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </div>
   <?php endif; ?><?php /**PATH C:\xampp\htdocs\Gaming\resources\views/admin/product/comments.blade.php ENDPATH**/ ?>