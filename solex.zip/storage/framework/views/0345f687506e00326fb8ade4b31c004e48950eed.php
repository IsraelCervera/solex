<?php $__env->startSection('title','Gestión de categorías'); ?>
<?php $__env->startSection('styles'); ?>
<style type="text/css">
    .unstyled-button {
        border: none;
        padding: 0;
        background: none;
      }
</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('options'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('preference'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="page-header">
        <h3 class="page-title">
            Categorías
        </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <?php if(auth()->check()): ?>
                <?php if(auth()->user()->rol=='Administrador'): ?>
                <li class="breadcrumb-item"><a href="#">Panel administrador</a></li>
                <?php endif; ?>
                <?php endif; ?>
                <li class="breadcrumb-item active" aria-current="page">Categorías</li>
            </ol>
        </nav>
    </div>
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    
                    <div class="d-flex justify-content-between">
                        <h4 class="card-title">Categorías</h4>
                        
                        <?php if(auth()->check()): ?>
                        <?php if(auth()->user()->rol=='Administrador'): ?>
                        <div class="btn-group">
                            <a data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right">
                              <a href="<?php echo e(route('categories.create')); ?>" class="dropdown-item">Crear Categoria</a>
                              
                            </div>
                          </div>
                    </div>
                    <?php endif; ?>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table id="order-listing" class="table">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Nombre</th>
                                    <th>Descripción</th>
                                    <?php if(auth()->check()): ?>
                                    <?php if(auth()->user()->rol=='Administrador'): ?>
                                    <th>Acciones</th>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($category->id); ?></th>
                                    <td>
                                        <a href="<?php echo e(route('categories.show',$category)); ?>"><?php echo e($category->name); ?></a>
                                    </td>
                                    <td><?php echo e($category->description); ?></td>
                                    <?php if(auth()->check()): ?>
                                    <?php if(auth()->user()->rol=='Administrador'): ?>
                                    <td style="width: 50px;">

                                        <a class="jsgrid-button jsgrid-edit-button" href="<?php echo e(route('categories.edit', $category)); ?>" title="Editar">
                                            <i class="far fa-edit"></i>
                                        </a>

                                        <form style="display:inline" method="POST" action="<?php echo e(route('categories.destroy', $category)); ?>">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo method_field('DELETE'); ?>

                                        <button class="jsgrid-button jsgrid-delete-button unstyled-button" type="submit" title="Eliminar">
                                            <i class="far fa-trash-alt"></i>
                                        </button>
                                        </form>
                                        
                                    </td>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('melody/js/data-table.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GamingShop\resources\views/admin/category/index.blade.php ENDPATH**/ ?>