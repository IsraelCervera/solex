<?php $__env->startSection('title','Editar usuario'); ?>
<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('options'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('preference'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="page-header">
        <h3 class="page-title">
            Editar usuario
        </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Panel administrador</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('users.index')); ?>">Usuarios</a></li>
                <li class="breadcrumb-item active" aria-current="page">Editar usuario</li>
            </ol>
        </nav>
    </div>
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    
                    <div class="d-flex justify-content-between">
                        <h4 class="card-title">Editar usuario</h4>
                    </div>
                    <form class="form-inline" method="POST" action="<?php echo e(route('users.update', $user)); ?>">
                    <?php echo method_field('PUT'); ?>

                    <?php echo e(csrf_field()); ?>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                          <ul>
                              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><?php echo e($error); ?></li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </ul>
                      </div>
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label for="name">Nombre</label>
                        <input type="text" name="name" id="name" value="<?php echo e($user->name); ?>" class="form-control" placeholder="" aria-describedby="helpId">
                      </div>
                      <div class="form-group">
                        <label for="lastname">Apellido</label>
                        <input type="text" name="lastname" id="lastname" value="<?php echo e($user->lastname); ?>" class="form-control" placeholder="" aria-describedby="helpId">
                      </div>
                      <div class="form-group">
                        <label for="phone">Celular</label>
                        <input type="number" name="phone" id="phone" value="<?php echo e($user->phone); ?>" class="form-control" placeholder="" aria-describedby="helpId">
                      </div>
                      <div class="form-group">
                        <label for="email">Correo electrónico</label>
                        <input type="email" name="email" id="email" value="<?php echo e($user->email); ?>" class="form-control" placeholder="" aria-describedby="helpId">
                      </div>
                      
                      

                      <div class="form-group">
                          <label for="password">Contraseña</label>
                          <input type="password" name="password" id="password" value="<?php echo e($user->password); ?>" class="form-control" placeholder="" aria-describedby="helpId">
                          <small id="helpId" class="text-muted">Rellenar solo si desea cambiar la contraseña.</small>
                      </div>
                    

                     <button type="submit" class="btn btn-primary mr-2">Actualizar</button>
                     <a href="<?php echo e(route('users.index')); ?>" class="btn btn-light">
                        Cancelar
                     </a>
                     </form>
                </div>
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('melody/js/data-table.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GamingShop\resources\views/admin/user/edit.blade.php ENDPATH**/ ?>