<?php $__env->startSection('title','Información de la empresa'); ?>
<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('estilos/estilos.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('create'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('options'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('preference'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="page-header">
        <h3 class="page-title">
            <?php echo e($business->name); ?>

        </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <?php if(auth()->check()): ?>
                <?php if(auth()->user()->rol=='Administrador'): ?>
                <li class="breadcrumb-item"><a href="">Panel administrador</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('businesses.index')); ?>">Empresa</a></li>
                <?php endif; ?>
                <?php endif; ?>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($business->name); ?></li>
            </ol>
        </nav>
    </div>

<div class="row">
            <div class="col-md-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body d-flex flex-column">
                  <h4 class="card-title">
                    <i class="fas fa-chart-pie"></i>
                    Información de la empresa
                  </h4>
                  <div class="flex-grow-1 d-flex flex-column justify-content-between">

                    <strong><i class="fas fa-file-signature mr-1"></i>Nombre</strong>
                            <p class="text-muted">
                                <?php echo e($business->name); ?>

                            </p>
                    <strong><i class="fas fa-align-left mr-1"></i>Acerca de</strong>
                            <p class="text-muted">
                                <?php echo e($business->description); ?>

                            </p>
                    <strong><i class="fas fa-align-left mr-1"></i>Descripción</strong>
                            <p class="text-muted">
                                <?php echo e($business->description_long); ?>

                            </p>
                            <strong><i class="fas fa-envelope mr-1"></i>Correo</strong>
                            <p class="text-muted">
                                <?php echo e($business->mail); ?>

                            </p>
                            <strong><i class="fas fa-mobile mr-1"></i>Celular</strong>
                            <p class="text-muted">
                                <?php echo e($business->phone); ?>

                            </p>

                  </div>
                </div>
              </div>
            </div>

            <div class="col-md-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body d-flex flex-column">
                  <h4 class="card-title">
                    <i class="fas fa-chart-pie"></i>
                    Información de contacto
                  </h4>
                  <div class="flex-grow-1 d-flex flex-column">

                    <strong><i class="fas fa-file-signature mr-1"></i>Contacta con nosotros</strong>
                            <p class="text-muted">
                                <?php echo e($business->contact_text); ?>

                            </p>
                    <strong><i class="fas fa-align-left mr-1"></i>Horario</strong>
                            <p class="text-muted">
                                <?php echo e($business->hours_of_operation); ?>

                            </p>
                    <strong><i class="fas fa-align-left mr-1"></i>Enlace de Google Maps</strong>
                            <p class="text-muted">
                                <a href="<?php echo e($business->google_maps_link); ?>" target="_blank"><?php echo e($business->google_maps_link); ?></a>
                            </p>

                  </div>
                </div>
              </div>
            </div>
          </div>
                <div class="card-footer text-muted">
                    <?php if(auth()->check()): ?>
                    <?php if(auth()->user()->rol=='Administrador'): ?>
                    <a href="<?php echo e(route('businesses.index')); ?>" class="btn btn-primary float-right">Lista de Productos</a>
                    <?php endif; ?>
                    <?php endif; ?>
                    <a href="<?php echo e(route('home')); ?>" class="btn btn-primary float-right">Regresar al home</a>
                </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<!-- Custom js for this page-->

  <!-- End custom js for this page-->
<script src="<?php echo e(asset('melody/js/profile-demo.js')); ?>"></script>
<script src="<?php echo e(asset('melody/js/data-table.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\solex\resources\views/admin/business/show.blade.php ENDPATH**/ ?>