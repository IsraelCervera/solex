<?php $__env->startSection('contenido'); ?>
<link rel="stylesheet" href="<?php echo e(asset('estilos/estilos.css')); ?>">

<?php echo $__env->make('admin.product.products_slyde', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.product.products_list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Gaming\resources\views/home.blade.php ENDPATH**/ ?>