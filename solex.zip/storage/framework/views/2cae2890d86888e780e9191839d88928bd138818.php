<?php $__env->startSection('contenido'); ?>
<h1>Editar Comentario</h1>

<form class="form-inline" method="POST" action="<?php echo e(route('comentarios.update', $comments->id)); ?>">

<?php echo method_field('PUT'); ?>

<?php echo e(csrf_field()); ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
     	<ul>
	        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	        <li><?php echo e($error); ?></li>
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    </ul>
	</div>
<?php endif; ?>

<label for="body">
	Comentario<br>
	<textarea class="form-control" name="body"><?php echo e($comments->body); ?></textarea>
</label><br><br>
<input class="btn btn-primary" type="submit" value="Enviar">
	
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GamingShop\resources\views/comments/edit.blade.php ENDPATH**/ ?>