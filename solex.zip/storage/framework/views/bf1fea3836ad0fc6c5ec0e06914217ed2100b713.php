<div class="brand_color">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="titlepage">
                        <h2>Servicios</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>

<!-- brand -->
    <div class="brand">
        <div class="container">

        </div>
        <div class="brand-bg">
            <div class="container">
                <div class="row">
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6 margin">
                        <div class="brand_box">
                            <img src="<?php echo e(asset('service/'.$service->image)); ?>" alt="img" />
                            <h3><a><?php echo e($service->name); ?></a></h3>
                            <h4>$<strong class="red"><?php echo e($service->sell_price); ?></strong></h4>
                            <span><?php echo e($service->category->name); ?></span>
                            <a href="<?php echo e(route('web.service_details', $service)); ?>" class="read-more">Leer más</a>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12">
                        <a href="<?php echo e(route('web.service')); ?>" class="read-more">Todos los servicios</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end brand --><?php /**PATH C:\xampp\htdocs\solex\resources\views/web/service/service_list.blade.php ENDPATH**/ ?>