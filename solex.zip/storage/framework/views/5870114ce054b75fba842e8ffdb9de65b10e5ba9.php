<?php $__env->startSection('contenido'); ?>
<?php if(session()->has('info')): ?>
<h3><?php echo e(session('info')); ?></h3>
<?php else: ?>

	    <div class="container-login">
		<div class="wrap-login">
<form method="POST" action="<?php echo e(route('users.store')); ?>">
	<span class="login-form-title">REGISTRO</span>
	<?php echo e(csrf_field()); ?>

	<?php if($errors->any()): ?>
    <div class="alert alert-danger">
     	<ul>
	        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	        <li><?php echo e($error); ?></li>
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    </ul>
	</div>
	<?php endif; ?>

    <div class="wrap-input100">
    <input class="input100" type="text" name="name" placeholder="Nombre" value="<?php echo e(old('name')); ?>">
    <span class="focus-efecto"></span>
    </div>

    <div class="wrap-input100">
    <input class="input100" type="text" name="lastname" placeholder="Apellido" value="<?php echo e(old('lastname')); ?>">
    <span class="focus-efecto"></span>
    </div>

    <div class="wrap-input100">
    <input class="input100" type="text" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>">
    <span class="focus-efecto"></span>
    </div>

    <div class="wrap-input100">
    <input class="input100" type="number" name="phone" placeholder="Teléfono" value="<?php echo e(old('phone')); ?>">
    <span class="focus-efecto"></span>
    </div>

    <div class="wrap-input100">
    <input class="input100" type="address" name="address" placeholder="Dirección" value="<?php echo e(old('address')); ?>">
    <span class="focus-efecto"></span>
    </div>

    <div class="wrap-input100">
    <input class="input100" type="state" name="state" placeholder="Estado" value="<?php echo e(old('state')); ?>">
    <span class="focus-efecto"></span>
    </div>

    <div class="wrap-input100">
    <input class="input100" type="cp" name="cp" placeholder="Codigo Postal" value="<?php echo e(old('cp')); ?>">
    <span class="focus-efecto"></span>
    </div>

    <div class="wrap-input100">
    <input class="input100" type="text" name="rol" placeholder="Rol" value="<?php echo e(old('rol')); ?>">
    <span class="focus-efecto"></span>
    </div>

    <div class="wrap-input100">
    <input class="input100" type="password" name="password" placeholder="Password">
    <span class="focus-efecto"></span>
    </div>

	<div class="container-login-form-btn">
    <div class="wrap-login-form-btn">
    <div class="login-form-bgbtn"></div>
    <button type="submit" name="submit" class="login-form-btn">ENVIAR</button>
    </div>
    </div>

</form>
</div>
</div>
<?php endif; ?>
<hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Gaming\resources\views/users/create.blade.php ENDPATH**/ ?>