<?php $__env->startSection('title','Información de la publicación'); ?>
<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('estilos/estilos.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('create'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('options'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('preference'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="page-header">
        <h3 class="page-title">
            <?php echo e($post->title); ?>

        </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <?php if(auth()->check()): ?>
                <?php if(auth()->user()->rol=='Administrador'): ?>
                <li class="breadcrumb-item"><a href="">Panel administrador</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('posts.index')); ?>">Productos</a></li>
                <?php endif; ?>
                <?php endif; ?>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($post->title); ?></li>
            </ol>
        </nav>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="border-bottom text-center pb-4">

                                <img src="<?php echo e(asset('slug/'.$post->slug)); ?>" style="max-height: 350px; max-width: 350px;" />
                                


                                <h3><?php echo e($post->name); ?></h3>
                                <div class="d-flex justify-content-between">
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-8 pl-lg-5">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h4>Información de la publicación</h4>
                                </div>
                            </div>
                            <div class="profile-feed">
                                <div class="d-flex align-items-start profile-feed-item">

                                    <div class="form-group col-md-6">
                                        <strong><i class="fab fa-product-hunt mr-1"></i> Resumen de la publicación</strong>
                                        <p class="text-muted">
                                            <?php echo e($post->excerpt); ?>

                                        </p>
                                        <hr>
                                        <strong><i class="fab fa-product-hunt mr-1"></i> Contenido de la publicación</strong>
                                        <p class="text-muted">
                                            <?php echo e($post->body); ?>

                                        </p>
                                        <hr>
                                        <strong><i class="fas fa-mobile mr-1"></i> iFrame</strong>
                                        <p class="text-muted">
                                            <?php echo e($post->iframe); ?>

                                        </p>
                                        <hr>
                                        <strong><i class="fas fa-mobile mr-1"></i> Fecha de publicación</strong>
                                        <p class="text-muted">
                                            <?php echo e($post->created_at); ?>

                                        </p>
                                        <hr>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer text-muted">
                    <?php if(auth()->check()): ?>
                    <?php if(auth()->user()->rol=='Administrador'): ?>
                    <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-primary float-right">Lista de Publicaciones</a>
                    <?php endif; ?>
                    <?php endif; ?>
                    <a href="<?php echo e(route('home')); ?>" class="btn btn-primary float-right">Regresar al home</a>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('melody/js/profile-demo.js')); ?>"></script>
<script src="<?php echo e(asset('melody/js/data-table.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\solex\resources\views/admin/post/show.blade.php ENDPATH**/ ?>