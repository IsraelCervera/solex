<?php $__env->startSection('contenido'); ?>

        <?php if(count(Cart::getContent())): ?>
        <table class="table">
          <thead>
            <th>ID</th>
            <th>Nombre</th>
            <th>Precio</th>
            <th>Cantidad</th>
            <th>Acciones</th>
          </thead>
          <tbody>
            <?php $__currentLoopData = Cart::getContent(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($product->id); ?></td>
              <td><?php echo e($product->name); ?></td>
              <td><?php echo e($product->price); ?></td>
              <td><?php echo e($product->quantity); ?></td>
              <td>
                <button class="btn btn-success" onclick="location.href='<?php echo e(route('sales.create')); ?>'">BUY</button>
                <form style="display:inline" method="POST" action="<?php echo e(route('cart.removeitem')); ?>">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
          <button class="btn btn-danger" type="submit">DELETE</button>
        </form>
      </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>

        <?php else: ?>
        <p>Carrito vacio</p>
        <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GamingShop\resources\views/checkout.blade.php ENDPATH**/ ?>