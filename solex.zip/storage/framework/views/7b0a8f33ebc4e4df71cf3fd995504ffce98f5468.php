<!DOCTYPE html>
<html lang="en">



<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Sistema Punto De Venta</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo e(asset('melody/vendors/iconfonts/font-awesome/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('melody/vendors/css/vendor.bundle.base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('melody/vendors/css/vendor.bundle.addons.css')); ?>">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
    <link rel="stylesheet" href="<?php echo e(asset('melody/css/style.css')); ?>">
  <!-- endinject -->
  <link rel="shortcut icon" href="melody/images/favicon.png" />
</head>

<body>
  <?php if(session('message')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('message')); ?>

    </div>
<?php endif; ?>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-stretch auth auth-img-bg">
        <div class="row flex-grow">
          <div class="col-lg-6 d-flex align-items-center justify-content-center">
            <div class="auth-form-transparent text-left p-3">
              <div class="brand-logo">
              </div>
              <button class="btn btn-info" onclick="location.href='<?php echo e(route('register')); ?>'">REGISTRARSE</button>
              <h4>Israel Cervera Alvarado</h4>
              <h6 class="font-weight-light">Curso De Ventas</h6>


              <?php echo $__env->yieldContent('content'); ?>


            </div>
          </div>
          <div class="col-lg-6 login-half-bg d-flex flex-row">
            <p class="text-white font-weight-medium text-center flex-grow align-self-end">Copyright &copy; 2020 Todos los derechos reservados <a>Israel</a></p>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="<?php echo e(asset('melody/vendors/js/vendor.bundle.base.js')); ?>"></script>
  <script src="<?php echo e(asset('melody/vendors/js/vendor.bundle.addons.js')); ?>"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="<?php echo e(asset('melody/js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(asset('melody/js/hoverable-collapse.js')); ?>"></script>
  <script src="<?php echo e(asset('melody/js/misc.js')); ?>"></script>
  <script src="<?php echo e(asset('melody/js/settings.js')); ?>"></script>
  <script src="<?php echo e(asset('melody/js/todolist.js')); ?>"></script>
  <!-- endinject -->
</body>
</html>
<?php /**PATH C:\xampp\htdocs\GamingShop\resources\views/layouts/login.blade.php ENDPATH**/ ?>