<?php $__env->startSection('styles'); ?>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('galio/assets/css/bootstrap.min.css')); ?>">
    <!-- Font-Awesome CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('galio/assets/css/font-awesome.min.css')); ?>">
    <!-- helper class css -->
    <link rel="stylesheet" href="<?php echo e(asset('galio/assets/css/helper.min.css')); ?>">
    <!-- Plugins CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('galio/assets/css/plugins.css')); ?>">
    <!-- Main Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('galio/assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('galio/assets/css/skin-default.css')); ?>" id="galio-skin">

<?php $__env->startSection('contenido'); ?>
        <div class="col-lg-12 col-md-12">
                                    
                                        
            <div class="myaccount-content">
                <h3 class="text-dark">Pedidos</h3>
                <div class="myaccount-table table-responsive text-center">
                    <table class="table table-bordered">
                        <thead class="thead-light">
                            <tr>
                                <th>Pedido</th>
                                <th>Fecha</th>
                                <th>Estado de envio</th>
                                <th>Estado de pago</th>
                                <th>Total</th>
                                <th>Acción</th>
                            </tr>
                        </thead>
                        <tbody class="text-dark">
                            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><a href="" class="check-btn sqr-btn "><?php echo e($order->id); ?></a></td>
                                <td><a href="" class="check-btn sqr-btn "><?php echo e($order->order_date); ?></a></td>
                                <td><a href="" class="check-btn sqr-btn "><?php echo e($order->shipping_status()); ?></a></td>
                                <td><a href="" class="check-btn sqr-btn "><?php echo e($order->payment_status()); ?></a></td>
                                <td><a href="" class="check-btn sqr-btn ">$MX <?php echo e($order->total()); ?></a></td>
                                <td><a href="<?php echo e(route('orders.show', $order)); ?>" class="check-btn sqr-btn ">View</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center text-light">NO HAY PEDIDOS.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Gaming\resources\views/web/orders.blade.php ENDPATH**/ ?>