<div id="products-list">
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="product-item col-md-10 pull-left panel panel-default">
            <div class="panel-body">
            <div class="product-image-thumb col-md-3 pull-left">
                <div class="product-image-mask">
            <img src="<?php echo e(url($product->image)); ?>" class="product-image">
            </div>
        </div>
           <div class="data">
                  <h5 class="product-title"><a href="<?php echo e(route('products.show', $product->id)); ?>"><?php echo e($product->title); ?></a></h5>
                  <p class="product-datos"><a class="text-light" href="<?php echo e(route('categories', ['user_id' => $product->user->id])); ?>"> <?php echo e('Subido por'.' '.$product->user->name.' '.$product->user->lastname); ?></a></p>
                  <p class="product-datos"><?php echo e(\FormatTime::LongTimeFilter($product->created_at)); ?></p>
          </div>

          <?php if(Auth::check() && Auth::user()->id == $product->user_id): ?>
          <button class="btn btn-success" onclick="location.href='<?php echo e(route('products.show', $product->id)); ?>'">Ver</button>

            <button class="btn btn-info" onclick="location.href='<?php echo e(route('products.edit', $product->id)); ?>'">
            Editar</button>

            <form style="display:inline" method="POST" action="<?php echo e(route('products.destroy', $product->id)); ?>">

                <?php echo e(csrf_field()); ?>

                <?php echo method_field('DELETE'); ?>

                    <button class="btn btn-danger" type="submit">Eliminar</button>
                </form>
            <?php endif; ?>
    </div>
    </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div><?php /**PATH C:\xampp\htdocs\GamingShop\resources\views/products/products_list.blade.php ENDPATH**/ ?>