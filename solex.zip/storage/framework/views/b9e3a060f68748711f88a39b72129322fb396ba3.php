<?php $__env->startSection('contenido'); ?>

        <link rel="stylesheet" href="<?php echo e(asset('estilos/bootstrap/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('estilos/estilos.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('estilos/plugins/sweetalert2/sweetalert2.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('estilos/fuentes/iconic/css/material-design-iconic-font.min.css')); ?>"> 

<h1>Editar Usuario</h1>

<form class="form-inline" method="POST" action="<?php echo e(route('usuarios.update', $users->id)); ?>">

<?php echo method_field('PUT'); ?>

<?php echo e(csrf_field()); ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
     	<ul>
	        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	        <li><?php echo e($error); ?></li>
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    </ul>
	</div>
<?php endif; ?>

<label for="name">
	Nombre
	<input class="form-control" type="text" name="name" value="<?php echo e($users->name); ?>">
</label>
<br><br>
<label for="lastname">
	Apellido
	<input class="form-control" type="text" name="lastname" value="<?php echo e($users->lastname); ?>">
</label><br><br>
<label for="email">
	Email
	<input class="form-control" type="text" name="email" value="<?php echo e($users->email); ?>">
</label><br><br>
<label for="phone">
	Teléfono
	<input class="form-control" type="number" name="phone" value="<?php echo e($users->phone); ?>">
</label><br><br>
<label for="rol">
	Rol
	<input class="form-control" type="text" name="rol" value="<?php echo e($users->rol); ?>">
</label><br><br>
<label for="password">
	Contraseña
	<input class="form-control" type="text" name="password" value="<?php echo e($users->password); ?>">
</label><br><br>
<input class="btn btn-primary" type="submit" value="Enviar">
	
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GamingShop\resources\views/users/edit.blade.php ENDPATH**/ ?>